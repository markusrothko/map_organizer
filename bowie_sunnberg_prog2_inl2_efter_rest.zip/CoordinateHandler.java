/*
Markus Bowie, 19841205-0075
Carl Sunnberg 19990330-3395
*/

import javafx.scene.control.Alert;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class CoordinateHandler extends Alert {
	//2 text fields, one for x, one for y
	private TextField xCordField = new TextField();
	private TextField yCordField = new TextField();

	
	public CoordinateHandler() {
		super(AlertType.CONFIRMATION);
		//Graphical representation of the textfields.
		GridPane grid = new GridPane();
		grid.addRow(0, new Label("x:"), xCordField);
		grid.addRow(1, new Label("y:"), yCordField);
		
		getDialogPane().setContent(grid);
	}
	
	//return the entered x coordinate
	public String getXCord() {
		return xCordField.getText();
	}
	//return the entered y coordinate
	public String getYCord() {
		return yCordField.getText();
	}

}