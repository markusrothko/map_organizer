/*
Markus Bowie, 19841205-0075
Carl Sunnberg 19990330-3395
*/
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class NamedPlace extends Place {
	private String toString;
	
	//Constructor for the NamedPlace class.
    public NamedPlace(String name, String category, double x, double y) {
    	super(name, category, x, y);
    	//The toString is created at the same time since that is used to save and load places.
    	toString = "Named," + super.category + "," + (int)x + "," + (int)y +"," + super.name;
    }

    //Description of NamedPlaces
    @Override
	public void showPlaceDescription() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText(name + " [ x" + posi.getXCoordinate() + " / y" + posi.getYCoordinate() + " ]");
		alert.setTitle(category);
		alert.showAndWait();
	}
    
    @Override
	public String toString() {
		return toString;
	}
}