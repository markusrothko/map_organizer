/*
Markus Bowie, 19841205-0075
Carl Sunnberg 19990330-3395
*/

import java.io.*;
import java.util.*;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.ObservableSet;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class MapSystem extends Application {

    private Stage primaryStage;

    //Oanvänd arraylist
    //private List<Place> place = new ArrayList<>();

    //Datastructure to store categories
    //Better to use hashmap?
    private TreeMap<String, HashSet<Place>> categoryList = new TreeMap<>();

    //All marked places
    private ObservableSet<Place> markedPlaces = FXCollections.observableSet();
    
    //Search based on position
    private Map<Position, Place> positionList = new HashMap<>();

    //Search based on name
    //Better to use hashmap?
    private TreeMap<String, HashSet<Place>> nameList = new TreeMap<>();

    
    //Boolean used for checking if the program has been modified
    private SimpleBooleanProperty programHasBeenModified = new SimpleBooleanProperty(false);
    
    //UI used in classes and methods
    private ImageView display;
    private Image map;
    private TextField searchField;
    private Pane kartRam;
    private ToggleGroup group = new ToggleGroup();
    private RadioButton namedPlace, describedPlace;
    private MenuBar dropDownMenu;
    private MenuItem saveItem, exitChoiceItem, loadMapItem, loadPlaces;
    private BorderPane root;
    private Button newButton, searchButton;
    private ObservableList<String> categories;
    private ListView<String> cat;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        root = new BorderPane();
        Scene scene = new Scene(root, 900, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Map System");
        primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, new ExitApplicationHandler());
        primaryStage.show();
        display = new ImageView();
        kartRam = new Pane();
        kartRam.getChildren().add(display);
        root.setCenter(kartRam);

        //Top area, file menu
        VBox vbox = new VBox();
        dropDownMenu = new MenuBar();
        vbox.getChildren().add(dropDownMenu);
        Menu archiveMenu = new Menu("File");
        dropDownMenu.getMenus().add(archiveMenu);
        loadMapItem = new MenuItem("Load Map");
        archiveMenu.getItems().add(loadMapItem);
        loadMapItem.setOnAction(new LoadMapHandler());
        loadPlaces = new MenuItem("Load Places");
        archiveMenu.getItems().add(loadPlaces);
        loadPlaces.setOnAction(new LoadPlacesHandler());
        saveItem = new MenuItem("Save");
        archiveMenu.getItems().add(saveItem);
        saveItem.setOnAction(new SavePlacesHandler());
        exitChoiceItem = new MenuItem("Exit");
        archiveMenu.getItems().add(exitChoiceItem);
       
        exitChoiceItem.setOnAction(
                action -> primaryStage.fireEvent(new WindowEvent(primaryStage, WindowEvent.WINDOW_CLOSE_REQUEST)));

        //Top area input
        HBox hboxTop = new HBox();
        vbox.getChildren().add(hboxTop);
        hboxTop.setPadding(new Insets(10));
        hboxTop.setSpacing(10);
        hboxTop.setAlignment(Pos.CENTER);
        newButton = new Button("New");
        newButton.setOnAction(new NewLocation());
        VBox vbs = new VBox();
        vbs.setSpacing(10);
        vbs.setPadding(new Insets(10));

        //Radiobuttons
        namedPlace = new RadioButton("Named");
        describedPlace = new RadioButton("Described");
        vbs.getChildren().addAll(namedPlace, describedPlace);
        namedPlace.setToggleGroup(group);
        describedPlace.setToggleGroup(group);
        namedPlace.setSelected((true));

        searchButton = new Button("Search");
        searchField = new TextField();
        searchField.setPromptText("Enter search:");
        searchButton.setOnAction(new SearchHandler());
        Button hideButton = new Button("Hide");
        hideButton.setOnAction(new HideHandler());
        Button removeButton = new Button("Remove");
        removeButton.setOnAction(new RemoveHandler());
        Button coordinatesButton = new Button("Coordinates");
        coordinatesButton.setOnAction(new CoordinateSearch());

        //Right area, categories
        VBox listan = new VBox();
        listan.setPadding(new Insets(5));
        cat = new ListView<String>();
        categories = FXCollections.observableArrayList("Bus", "Train", "Underground");
        listan.getChildren().add(new Label("Categories"));
        listan.getChildren().add(cat);
        cat.setItems(categories);
        listan.setAlignment(Pos.CENTER);
        Button hideCategoryButton = new Button("Hide Category");
        hideCategoryButton.setOnAction(new HideCategoryButtonHandler());
        hideCategoryButton.setAlignment(Pos.CENTER);
        listan.getChildren().add(hideCategoryButton);
        listan.setPrefSize(145, 100);
        cat.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                DisplayCategoryAction();
            }
        });
        hboxTop.getChildren().addAll(newButton, vbs, searchField, searchButton, hideButton, removeButton,
                coordinatesButton);
        root.setTop(vbox);
        root.setRight(listan);
    }

    //A method that returns the selected category in the categories listview
    private String getSelectedCategory() {
        if (cat.getSelectionModel().getSelectedItem() == null)
            return "None";
        return cat.getSelectionModel().getSelectedItem();
    }

    //Store a new place in datastructures, one for searching after coordinates and one for searching after name
    private void storePlace(Place newPlace) {
        markedPlaces.add(newPlace);
        newPlace.getBool().addListener((obs, old, nevv) -> {
            if (nevv == true)
                markedPlaces.add(newPlace);
            else if (nevv == false)
                markedPlaces.remove(newPlace);
        });

        nameList.putIfAbsent(newPlace.getName(), new HashSet<Place>());
        nameList.get(newPlace.getName()).add(newPlace);
        categoryList.putIfAbsent(newPlace.getCategory(), new HashSet<Place>());
        categoryList.get(newPlace.getCategory()).add(newPlace);
        positionList.put(newPlace.getPosi(), newPlace);
        root.getChildren().add(newPlace);
    }
    
  //The exit handler if clicked on exit in the filemenu
    class ExitApplicationHandler implements EventHandler<WindowEvent> {
        @Override
        public void handle(WindowEvent event) {
            //Check if there are unsaved changes
            if (programHasBeenModified.get()) {
                //If there are unchanged changes: display an confirmation alert
                Optional<ButtonType> response = new Alert(AlertType.CONFIRMATION, "There are unsaved changes.\nQuit?")
                        .showAndWait();
                //Let user cancel the action
                if (response.isPresent() && response.get() == ButtonType.CANCEL || response.get() == ButtonType.CLOSE)
                    event.consume();
                //programHasBeenModified.set(false);
            }
        }
    }
    
    //A handler for when loading a map
    class LoadMapHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            if (programHasBeenModified.get()) {
                //If there are unchanged changes: display an confirmation alert
                Optional<ButtonType> response = new Alert(AlertType.CONFIRMATION, "There are unsaved changes.\nLoad new map anyway?")
                        .showAndWait();
                //Let user cancel the action

                if (response.isPresent() && response.get() == ButtonType.CANCEL || response.get() == ButtonType.CLOSE)
                    return;
                event.consume();
            }

            try {
                //Open filedhandler so user can choose
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Open Map File");
                fileChooser.getExtensionFilters()
                        .addAll(new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png"));
                File file = fileChooser.showOpenDialog(primaryStage);
                if (file == null)
                    return;

                String fileName = file.getAbsolutePath();
                kartRam.getChildren().clear();
                root.getChildren().clear();
                start(primaryStage);
                FileInputStream fis = new FileInputStream(fileName);
                //Display new map
                map = new Image(new FileInputStream(fileName));
                display.setImage(map);
                markedPlaces.clear();
                nameList.clear();
                positionList.clear();
                categoryList.clear();
                fis.close();
                //Catch any IO exceptions
            } catch (FileNotFoundException fnfe) {
                System.err.println("No such file.");
                System.err.println("Fatal error.");
            } catch (IOException ioe) {
                System.err.println("IO-error.");
                System.err.println(ioe.getMessage());
            }
        }
    }
    
    //Used when loading a new map
    private void updateMap() {
        kartRam.getChildren().clear();
        kartRam.getChildren().add(display);
        for (Map.Entry<Position, Place> p : positionList.entrySet()) {
        kartRam.getChildren().add(p.getValue());
        }
    }

    class LoadPlacesHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            if (unsaved()) {
                //Open filedhandler so user can choose
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Choose your place file:");
                fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Places file", "*.places"));
                File choosenFile = fileChooser.showOpenDialog(primaryStage);
                if (choosenFile != null) {
                    deleteAll();
                    updateMap();
                    programHasBeenModified.set(false);
                    try {
                        FileReader file = new FileReader(choosenFile);
                        BufferedReader bufferedFile = new BufferedReader(file);
                        String line;
                        //Display places
                        try {
                            while ((line = bufferedFile.readLine()) != null)
                                createPlace(line.split(","));
                            deSelectAll();
                            new Alert(AlertType.INFORMATION, "New places loaded.").showAndWait();
                        } catch (Exception e) {
                            new Alert(AlertType.ERROR, "Unknown file format.").showAndWait();
                        }
                        file.close();
                        bufferedFile.close();
                        //Catch any IO exceptions
                    } catch (IOException e) {
                        new Alert(AlertType.ERROR, "Unable to open Place file").showAndWait();
                    }
                }
            }
        }

        //Create the new places from the place file
        private void createPlace(String[] arg) {
            if (arg[0].equals("Named"))
                storePlace(new NamedPlace(arg[4], arg[1], Double.parseDouble(arg[2]), Double.parseDouble(arg[3])));
            else if (arg[0].equals("Described"))
                storePlace(new DescribedPlace(arg[4], arg[1], Double.parseDouble(arg[2]), Double.parseDouble(arg[3]),
                        arg[5]));
        }
    }

    //Save function
    class SavePlacesHandler implements EventHandler<ActionEvent> {
        //Runs the file chooser
        @Override
        public void handle(ActionEvent event) {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose places file");
            fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Places files", "*.places"));
            File choosenFile = fileChooser.showSaveDialog(primaryStage);

            //saves the file, including error message
            if (choosenFile != null) {
                programHasBeenModified.set(false);
                try {
                    FileWriter file = new FileWriter(choosenFile);
                    PrintWriter outBound = new PrintWriter(file);
                    for (Map.Entry<Position, Place> p : positionList.entrySet())
                        outBound.println(p.getValue().toString());
                    file.close();
                    outBound.close();
                    new Alert(AlertType.INFORMATION, "Places saved.").showAndWait();
                } catch (IOException e) {
                    new Alert(AlertType.ERROR, "Unable to save place file.").showAndWait();
                }
            }
        }
    }
    
  //Checks if the user has made any unsaved changes to the places file and waits for user input
    private boolean unsaved() {
        Optional<ButtonType> response = null;
        if (programHasBeenModified.get())
            response = new Alert(AlertType.CONFIRMATION,
                    "There are unsaved changes.\nYour unsaved places will be removed.").showAndWait();
        if (!programHasBeenModified.get() || response.isPresent() && response.get() == ButtonType.OK)
            return true;
        return false;
    }
    
  //Search for place by name using nameList and makes the visible and selected on the map
    class SearchHandler implements EventHandler<ActionEvent> {
        HashSet<Place> searchOutput;

        @Override
        public void handle(ActionEvent event) {
            deSelectAll();
            if ((searchOutput = nameList.get(searchField.getText())) != null)
            	showOutput();
        }

        private void showOutput() {
            for (Place place : searchOutput)
                if (place.getName().equals(searchField.getText())) {
                	place.setVisible(true);
                	place.setMarkedProperty(true);
                }
        }
    }

    //Search by coordinate function
    class CoordinateSearch implements EventHandler<ActionEvent> {
        public void handle(ActionEvent event) {
            try {
                //Opens CoordinateHandler dialog window
                CoordinateHandler dialog = new CoordinateHandler();
                dialog.setTitle("Enter coordinates:");
                Optional<ButtonType> response = dialog.showAndWait();
                //Checks the user input
                if (response.isPresent() && response.get() == ButtonType.OK) {
                    if (Double.parseDouble(dialog.getXCord()) >= 0 && Double.parseDouble(dialog.getYCord()) >= 0) {
                        //Matches user input with coordinates in positionList
                        if (positionList.containsKey(new Position(Double.parseDouble(dialog.getXCord()),
                                Double.parseDouble(dialog.getYCord())))) {
                            Place place = positionList.get(new Position(Double.parseDouble(dialog.getXCord()),
                                    Double.parseDouble(dialog.getYCord())));
                            deSelectAll();
                            place.setMarkedProperty(true);
                            place.setVisible(true);
                        } else {
                        	new Alert(AlertType.ERROR, "No places found at entered coordinate.").showAndWait();
                        }
                    }
                }
                //Error handlers
            } catch (NumberFormatException e) {
                Alert msg = new Alert(AlertType.ERROR);
                msg.setContentText("Error, incorrect input!");
                msg.showAndWait();
            } catch (NullPointerException e) {
                Alert msg = new Alert(AlertType.ERROR);
                msg.setContentText("Error, enter all fields please");
                msg.showAndWait();
            }

        }
    }

    //NewLocation, in combination with one of the two following methods, is used to create a new place
    class NewLocation implements EventHandler<ActionEvent> {
        private Place newP;

        @Override
        public void handle(ActionEvent event) {
            newButton.setDisable(true);
            kartRam.setCursor(Cursor.CROSSHAIR);
            //Checks whether the user wishes to create a Named Place or a Described Place
            if (namedPlace.isSelected()) {
                kartRam.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        createNamedPlace(event.getX(), event.getY());
                    }
                });
            } else {
                kartRam.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        createDescribedPlace(event.getX(), event.getY());
                    }
                });
            }
        }

        //Creating a named place, including error message and reset
        private void createNamedPlace(double x, double y) {
            if (!positionList.containsKey(new Position(x, y))) {
                NamedPlaceHandler named = new NamedPlaceHandler(x, y);
                Optional<ButtonType> response = named.showAndWait();
                if (response.isPresent() && response.get() == ButtonType.OK) {
                    newP = new NamedPlace(named.getName(), getSelectedCategory(), x, y);
                    storePlace(newP);
                    programHasBeenModified.set(true);
                }
            } else
                error("Unable to create place here!");
            //Restores the functionality of the mouse cursor and the new-button
            newButton.setDisable(false);
            kartRam.setOnMouseClicked(null);
            kartRam.setCursor(Cursor.DEFAULT);
        }

        //Creating a described place, including error message and reset
        private void createDescribedPlace(double x, double y) {
            if (!positionList.containsKey(new Position(x, y))) {
                DescribedPlaceHandler described = new DescribedPlaceHandler(x, y);
                Optional<ButtonType> response = described.showAndWait();
                if (response.isPresent() && response.get() == ButtonType.OK) {
                    newP = new DescribedPlace(described.getName(), getSelectedCategory(), x, y,
                            described.getDescription());
                    storePlace(newP);
                    programHasBeenModified.set(true);
                }
            } else
                error("Unable to create place here!");
            newButton.setDisable(false);
            kartRam.setOnMouseClicked(null);
            kartRam.setCursor(Cursor.DEFAULT);
        }

        private void error(String text) {
            new Alert(AlertType.ERROR, text).showAndWait();
            kartRam.setOnMouseClicked(null);
            kartRam.setCursor(Cursor.DEFAULT);
        }

    }
    
    //Removes the selected places from all data structures
    class RemoveHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Iterator<Place> iterator = markedPlaces.iterator();
            while (iterator.hasNext()) {
                Place place = iterator.next();
                iterator.remove();
                clearFromAll(place);
            }
            programHasBeenModified.set(true);
        }

        //used to remove a location form all data structures
        private void clearFromAll(Place place) {
            if (nameList.get(place.getName()).size() > 1)
                nameList.get(place.getName()).remove(place);
            else
                nameList.remove(place.getName());

            if (categoryList.get(place.getCategory()).size() > 1)
            	categoryList.get(place.getCategory()).remove(place);
            else
            	categoryList.remove(place.getCategory());

            positionList.remove(place.getPosi());
            markedPlaces.remove(place);
            kartRam.getChildren().remove(place);
            place.setVisible(false);
        }
    }
    
    //Clears all places from all data structures. Used when loading a new places file.
    private void deleteAll() {
        markedPlaces.clear();
        nameList.clear();
        positionList.clear();
        categoryList.clear();
    }

    //Hides the selected places
    class HideHandler implements EventHandler<ActionEvent> {
        public void handle(ActionEvent event) {
            hideButtonAction();
        }
    }

    private void hideButtonAction() {
        Iterator<Place> iterator = markedPlaces.iterator();

        while (iterator.hasNext()) {
            Place place = iterator.next();
            if (place.isMarked()) {
            	place.setVisible(false);
                iterator.remove();
                place.setMarkedProperty(false);
            }
        }
    }
    
  //Hides all places of the selected category
    class HideCategoryButtonHandler implements EventHandler<ActionEvent> {
        public void handle(ActionEvent event) {
            HideCategoryButtonAction();
        }
    }

    public void HideCategoryButtonAction() {

        for (Place place : categoryList.get(getSelectedCategory())) {
        	place.setMarkedProperty(false);
        	place.setVisible(false);
        }
    }

    //Display all places of the selected category
    class DisplayCategoryHandler implements EventHandler<ActionEvent> {
        public void handle(ActionEvent event) {
            DisplayCategoryAction();
        }
    }

    public void DisplayCategoryAction() {
        deSelectAll();
        try {
            for (Place place : categoryList.get(getSelectedCategory())) {
            	place.setVisible(true);
            	place.setMarkedProperty(true);
            }
        } catch (NullPointerException e) {
        }
    }

    //Unmarks all places
    private void deSelectAll() {
        Iterator<Place> iterator = markedPlaces.iterator();
        while (iterator.hasNext()) {
            Place place = iterator.next();
            if (place.isMarked()) {
                iterator.remove();
                place.setMarkedProperty(false);
            }
        }
    }

    //Main method
    public static void main(String[] args) {
        launch(args);
    }
}