/*
Markus Bowie, 19841205-0075
Carl Sunnberg 19990330-3395
*/
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class DescribedPlace extends Place {

	private String description = "null", toString;
	
	//Constructor for the NamedPlace class.
	public DescribedPlace(String name, String category, double x, double y, String description) {
		super(name, category, x, y);
		if (!description.equals(""))
			this.description = description;
		toString = "Described," + category + "," + (int) x + "," + (int) y + "," + super.name + "," + this.description;
	}
	
	public String getDescription() {
		return description;
	}
	
	//DescribedPlace has its own type of description
	@Override
	public void showPlaceDescription() {
		Alert alert = new Alert(AlertType.INFORMATION, description);
		alert.setHeaderText(name + " [ x" + posi.getXCoordinate() + " / y" + posi.getYCoordinate() + " ]");
		//alert.setTitle(category);
		alert.showAndWait();
	}
	
	@Override
	public String toString() {
		return toString;
	}
}