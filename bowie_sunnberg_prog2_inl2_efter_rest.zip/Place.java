/*
Markus Bowie, 19841205-0075
Carl Sunnberg 19990330-3395
*/

import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.EventHandler;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public abstract class Place extends Polygon {
	protected final String name;
	protected final String category;
	private final Color color, markedColor;
	private SimpleBooleanProperty isMarked = new SimpleBooleanProperty();
	//Final on some variables since they wont be changed once objects are created.
	protected final Position posi;

	//Constructor for the place class.
	public Place(String name, String category, double x, double y) {
		//The name is null if the user doesn't write anything in the name field.
		//Error instead?
		if(!name.equals("")) {
        	this.name = name;
        } else {
        	this.name ="null";
        }
        posi = new Position(x, y);
        
		
		this.category = category;

		//Change so that the triangle gets marked by a mouse click
		this.setOnMouseClicked(new MarkerEvent());
		isMarked.set(true);
		
		//The selected category will give the triangles a specific color
		switch (category) {
		case "Bus":
			color = Color.RED;
			markedColor = Color.YELLOW;
			setupMarker();
			break;
		case "Train":
			color = Color.FORESTGREEN;
			markedColor = Color.YELLOW;
			setupMarker();
			break;
		case "Underground":
			color = Color.BLUE;
			markedColor = Color.YELLOW;
			setupMarker();
			break;
		default:
			//If there is no category selected, the triangle will be white.
			color = Color.WHITE;
			markedColor = Color.YELLOW;
			setupMarker();
		}

		
	}
	//The selection of the triangle:
	private void setupMarker() {
		getPoints().addAll(new Double[] { 0.0, 0.0, -10.0, -20.0, 10.0, -20.0 });
		setFill(color);
		relocate(getX(), getY());
		setMarkedProperty();
	}

	//The graphical representation of a marked or unmarked triangle
	private void setMarkedProperty() {
		if (isMarked.getValue()) {
			relocate(getX() - 10, getY() + 95);
			setStroke(Color.BLACK);
			setFill(markedColor);
			setStrokeWidth(3);
		} else {
			setStroke(null);
			setFill(color);
			relocate(getX() - 10, getY() + 95);
		}
	}
	
	public String getName() {
		return name;
	}

	public String getCategory() {
		return category;
	}
	
	public double getX() {
		return posi.getXCoordinate();
	}

	public double getY() {
		return posi.getYCoordinate();
	}

	public Position getPosi() {
		return posi;
	}
	
	public SimpleBooleanProperty getBool() {
		return isMarked;
	}

	public boolean isMarked() {
		return isMarked.getValue();
	}

	public void setMarkedProperty(boolean bool) {
		isMarked.set(bool);
		setMarkedProperty();
	}
	
	//A MouseEvent that checks if you right or left click a triangle.
	//Leftclick: the triangle is marked, Rightclick: information about the object appears.
	class MarkerEvent implements EventHandler<MouseEvent> {
		@Override
		public void handle(MouseEvent event) {
			if (event.getButton() == MouseButton.PRIMARY) {
				isMarked.set(!isMarked.getValue());
				setMarkedProperty();
			} else if (event.getButton() == MouseButton.SECONDARY)
				showPlaceDescription();
		}
	}
	//NamedPlace and DescribedPlace place have their own sort of description. 
	abstract void showPlaceDescription();
	
	@Override
	public abstract String toString();
}